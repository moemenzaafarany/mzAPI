<?php
/* 1.0.0 */
class mzPdf
{
}
